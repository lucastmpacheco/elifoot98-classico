#!/bin/sh
# Cria os atalhos do Elifoot 98 (o jogo e o editor) no menu de aplicativos do usuário, apontando para esta pasta.
set -e
PASTA="$(cd "$(dirname "$0")" && pwd)"
DEST="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
mkdir -p "$DEST"
for f in elifoot98.desktop elifoot98-editor.desktop; do
  sed "s|@PASTA@|$PASTA|g" "$PASTA/atalhos/$f" > "$DEST/$f"
  chmod +x "$DEST/$f"
done
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DEST" >/dev/null 2>&1 || true
echo "Atalhos criados em $DEST (Elifoot 98 e Elifoot 98 - Editor de Equipas)."
